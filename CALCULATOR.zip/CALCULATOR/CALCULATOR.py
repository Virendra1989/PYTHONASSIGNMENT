﻿import tkinter as tk
import math


window = tk.Tk()
window.geometry("300x400")
window.title("Calculator")


e = tk.Entry(window, width=20, borderwidth=5, font=("Arial", 18), justify="right")
e.grid(row=0, column=0, columnspan=4, padx=10, pady=10)

first = None
operator = None


def click(ch):
    cur = e.get()
    e.delete(0, tk.END)
    e.insert(0, str(cur) + str(ch))

def store_operator(op):
    global first, operator
    val = e.get()
    try:
        first = float(val) if val != "" else 0.0
    except ValueError:
        first = 0.0
    operator = op
    e.delete(0, tk.END)

def equal():
    global first, operator
    val = e.get()
    try:
        second = float(val) if val != "" else 0.0
        result = None
        if operator == "+":
            result = first + second
        elif operator == "-":
            result = first - second
        elif operator == "*":
            result = first * second
        elif operator == "/":
            result = first / second
        elif operator == "^":
            result = first ** second
        elif operator == "%":
            result = first % second
        else:
            result = second

        if result is not None:
            if abs(result - int(result)) < 1e-10:
                e.delete(0, tk.END)
                e.insert(0, str(int(result)))
            else:
                e.delete(0, tk.END)
                e.insert(0, str(result))
    except ZeroDivisionError:
        e.delete(0, tk.END)
        e.insert(0, "Error: division by zero")
    except ValueError:
        e.delete(0, tk.END)
        e.insert(0, "Error")
    finally:
        first = None
        operator = None

def clear():
    global first, operator
    e.delete(0, tk.END)
    first = None
    operator = None

def backspace():
    cur = e.get()
    e.delete(0, tk.END)
    e.insert(0, cur[:-1])

def sqrt():
    try:
        val = float(e.get())
        e.delete(0, tk.END)
        e.insert(0, str(math.sqrt(val)))
    except ValueError:
        e.delete(0, tk.END)
        e.insert(0, "Error")


buttons = [
    ("7", 1, 0), ("8", 1, 1), ("9", 1, 2), ("/", 1, 3),
    ("4", 2, 0), ("5", 2, 1), ("6", 2, 2), ("*", 2, 3),
    ("1", 3, 0), ("2", 3, 1), ("3", 3, 2), ("-", 3, 3),
    ("0", 4, 0), (".", 4, 1), ("=", 4, 2), ("+", 4, 3),
    ("Clear", 5, 0), ("⌫", 5, 1), ("√", 5, 2), ("^", 5, 3),
    ("%", 6, 0)
]

for (text, row, col) in buttons:
    if text.isdigit() or text == ".":
        tk.Button(window, text=text, width=5, height=2, command=lambda t=text: click(t)).grid(row=row, column=col, padx=5, pady=5)
    elif text in ["+", "-", "*", "/", "^", "%"]:
        tk.Button(window, text=text, width=5, height=2, command=lambda t=text: store_operator(t)).grid(row=row, column=col, padx=5, pady=5)
    elif text == "=":
        tk.Button(window, text=text, width=5, height=2, command=equal).grid(row=row, column=col, padx=5, pady=5)
    elif text == "Clear":
        tk.Button(window, text=text, width=5, height=2, command=clear).grid(row=row, column=col, padx=5, pady=5)
    elif text == "⌫":
        tk.Button(window, text=text, width=5, height=2, command=backspace).grid(row=row, column=col, padx=5, pady=5)
    elif text == "√":
        tk.Button(window, text=text, width=5, height=2, command=sqrt).grid(row=row, column=col, padx=5, pady=5)


window.bind("<Return>", lambda event: equal())
window.bind("<Escape>", lambda event: clear())
window.bind("<BackSpace>", lambda event: backspace())

window.mainloop()
